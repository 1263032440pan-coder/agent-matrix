## 3. Agent 生命周期（六态 FSM）

### 3.1 状态机

```
CREATED ──→ IDLE ⇄ BUSY ──→ PAUSED ──→ TERMINATED
              │       │        │
              └─失败──┴─超时───┘
                  ↓
              DEGRADED ──→ 自愈→IDLE / 不可恢复→TERMINATED
```

### 3.2 状态语义与转移表

| 状态 | 含义 | 进入 | 退出 |
|---|---|---|---|
| CREATED | 实例化完成未启动 | 路由命中/用户创建 | 首任务 → IDLE |
| IDLE | 活着待命（上下文预热） | 任务完成/启动完成 | 新任务 → BUSY |
| BUSY | 执行任务（工具循环运行） | 领到任务 | 终态 → IDLE；异常 → DEGRADED |
| PAUSED | 人工/Controller 暂停（保留会话上下文） | 用户/Controller 暂停；Controller 纠正（先暂停再重启任务） | 恢复 → IDLE；放弃 → TERMINATED |
| DEGRADED | 连续失败≥3 / 插件不可用 / 配额耗尽 | 失败计数阈值 | 冷却 60s 自愈 → IDLE；判定不可恢复 → TERMINATED |

**DEGRADED 中途快照（V1.3 补——接班说明的闭环）**：卡片只在任务终态生成（§7.6 归档检查点），而 DEGRADED 发生在任务中途——中途 4 轮工具消息未归档，新实例接手无依据。因此 **DEGRADED 进入时强制触发中途快照**：当前任务已累积消息即时摘要成卡片（含进行中/阻塞/相关文件——§7.5+ 接班说明字段）+ 完整消息落外置层（artifact 归档）——无论自愈继续还是换新实例，接手语义闭环。
| TERMINATED | 终局（实例记录与全部 ACP 消息归档保留审计） | 项目收尾/用户删除/不可恢复故障 | —（只读态） |

**转移纪律（复用既有 FSM actor 防护模式）**：
- 每条转移带 actor 约束：`PAUSED` 仅 Controller 或用户（Agent 自己不能）；`BUSY→IDLE` 仅执行链回调；`→TERMINATED` 仅 Controller/用户/生命周期钩子
- 非法转移拒绝并审计事件（照搬 StateTransitionService 模式）

### 3.3 生命周期事件（七类，全进 Event 系统）

`AGENT_CREATED / AGENT_IDLE / AGENT_BUSY / AGENT_PAUSED / AGENT_DEGRADED / AGENT_RECOVERED / AGENT_TERMINATED`——payload 带 agent_id/instance_id/project_id/原因字段。Controller 巡检与 UI 监控面板直接消费。

### 3.4 Controller（特殊 Agent——既有规划智能体的 Agent 化 + 新增管理职能）

**定位澄清（用户决策 2026-10-12）**：Controller 不是新建的岗位——它就是**既有的项目规划链路（/plan 全链）的智能体化**。规划构建（流程组织/各环节工作内容 md/契约生产/重规划）自 D06-D10 起一直是这个"角色"的本职，Worker Runtime 不夺走也不降级它，只是把它从隐式的函数调用链升级为显式的 Agent 实体；在此基础上**新增**监控管理职能。

- 常驻（不参与六态业务转移；随项目启动创建、项目删除终止）
- **【既有本职，全部保留】**：
  - 项目流程构建：材料理解 → 流程阶段组织（skill 骨架/文档抽取/研究补齐的编排）
  - 各环节工作内容 md：任务图每节点的工作内容契约（Task.contract 生产者——任务描述/验收标准/依赖交接物）
  - 研究编排：方法缺口检测 → 联网研究触发 → 结论回流（既有 gap 链）
  - 重规划：四触发源检测 → 增量修订流程与契约
  - 产物落既有体系（ProjectPlaybook/Task.contract/Artifact）——产出的是管理产物而非交付物本身
- **【Work Runtime 新增职能】**：巡检（偏移检测）/ 纠正（ACP correction）/ 调度（Agent 路由）/ 生命周期权限（PAUSE/TERMINATE）
- **【交付清单对账循环——长文档续作问题的解法（用户决策 2026-10-12）】**：长开发文档（32KB+）没有任何智能体能单会话不中断完成——本项目的解法是 Controller 常驻对账，三层机制：
  - **检测（清单对账）**：规划期从文档抽出「交付清单」（全部待实现项+逐项验收标准——即 Task.contract 集）；执行中/后定期对账——复用 Traceability 覆盖图（WP-022 rebuild_scope 即对账查询：清单项→任务→产物有无链）+ CompletionCheck 七条件（WP-023）；三类结果：✓已覆盖 / ✗卡点（任务 FAILED/BLOCKED）/ ✗漏项（清单项无任务覆盖——长文档后半段被 LLM 遗忘的经典场景）
  - **决策（四动作）**：漏项→动态建任务（**新增第五触发源 RECONCILIATION_GAP**——V1.3 更正：既有 Replanner 四触发源（Gate FAIL/资产指纹/Research ANSWERED/understanding 前进）不含对账漏项，此为批次 2 新增触发源，经 Replanner.replan 主链复用建任务能力）；卡点→ACP correction/换 Agent 重派；质量差→REWORK（Gate FAIL 链路既有）；全绿→才允许项目完成
  - **驱动（停止条件改写）**：FULL_AUTO 推进循环的停止条件 = 清单全绿（不是任务队列空——"任务图跑完"但清单未对平时 Controller 继续对账补任务）；MANUAL 模式卡点主动请求用户（ManualAction 既有），但"提醒继续"本身不需要人
- **【防死循环五闸（用户确认 2026-10-12——自动验收循环系统的死亡螺旋防线）】**：
  1. **验收标准规划期冻结**：Task.contract 验收条款只在规划时写，执行期只做闭式逐条对照（boolean），不得新增/拔高标准；REWORK 指令必须引用具体条款（"违反条款 3: 404≠500"），禁止开放式挑刺（"测试不够充分"）——合同验收而非薛定谔验收。**冻结边界（V1.3 补）**：冻结粒度 = "已建任务的条款集不可变"；REPLAN/对账补建新任务属规划行为，新任务自带新契约**不受冻结约束**（但受闸②③④管——轮次/预算/熔断照样生效）——对账循环与冻结闸语义咬合，批次 2 Gate 校验按此实现
  2. **REWORK 轮次上限**（max_rework_rounds=3 默认可配）：第 3 轮 FAIL 后不再 REWORK，升级 ManualAction 三选一（降级接受 WAIVED+豁免理由留审计 / 换 Agent 或换模型 / 用户裁决）——系统永不自作主张第 4 轮
  3. **漏项补给预算**：对账补新任务 ≤ 原任务图节点数 50%（9 节点最多补 4）——超限停止补给升级用户（"文档过大/需求颗粒度不适配，建议拆项目"）
  4. **全局死循环熔断**：连续 8 次任务终态均 FAIL/REWORK → 判定系统性问题 → 项目自动 PAUSED + 报告用户，停止消耗 token
  5. **循环成本可见**：UI 任务卡显示 rework_round ×/3；项目页显示"对账第 N 轮 | 补给 m/预算 | 累计消耗"
  - **设计原则**："完成"必须有限可判定——验收条款有限集 + REWORK 有限轮 + 补给有限额 + 熔断有限触发，四层有限叠加数学上保证循环必然终止（完成或升级人类，无第三种无限状态）；宽松度旋钮只留两个且都归用户（max_rework_rounds / WAIVED 降级接受开关），不留给 LLM
- 插件配置：管理类（web_search/file_rw/code_search 只读），不挂 shell 执行/测试运行等干活插件
- 偏移检测复用 Gate 语义：CompletionCheck 七条件 + 任务契约对照——检测依据正是自己构建的契约（构建者最清楚验收标准，语义自洽）

---
