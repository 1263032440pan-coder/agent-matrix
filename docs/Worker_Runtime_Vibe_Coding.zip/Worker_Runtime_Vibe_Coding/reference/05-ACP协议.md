## 5. ACP 通信协议（项目内实现）

### 5.1 消息类型（五类）

| 类型 | 方向 | 用途 |
|---|---|---|
| `request` / `inform` | Agent↔Agent | 契约拉取与应答（编码→架构要接口定义）；依赖数据（测试→编码要函数签名） |
| `correction` | Controller→Agent | 偏移纠正（先 PAUSE 目标 Agent → 下发修正指令与依据 → 重启当前任务） |
| `report` | Agent→Controller | 冲突上报（需求矛盾请求裁决）；进度/风险上报 |
| `directive` | Controller→Agent | 调度指令（暂停等待上游/恢复执行） |
| `manifest_check`（审计事件） | Controller→系统 | 清单对账结果（对账轮次/✓数/✗卡点/✗漏项/补给动作）——驱动续作循环的可观测信号（§3.4 对账机制） |

### 5.2 交互内容原则

**每条 ACP 消息对应 TaskDependency 上具体交接物或裁决**——不做自由聊天。消息体：`{from_agent, to_agent, type, task_id?, payload, ts}`，全部落 `acp_message` 表 + Event 审计（可回放"谁在何时说了什么"）。

### 5.3 典型回路

```
偏移纠正: Controller 巡检发现编码 Agent 产出含未定义接口
  → correction{task_id, 依据: 契约§2+架构接口表, 指令: 按架构接口表修正}
  → 编码 Agent PAUSED → 收指令 → 重启任务 → 产出对齐 → report 复核

契约交互: 编码 Agent 工具循环中判缺接口定义
  → request{to: designer, what: "User 模块 API 契约"}
  → designer inform{接口表} → 编码继续
  （超时 120s 无响应 → 上报 Controller 裁决——不空等）
```

### 5.4 死锁与超时

- 环等待检测：任务图依赖边 + ACP 等待关系做图检测；发现环 → Controller 裁决（强制解除一侧 + 记录）
- 全部 request 带超时（120s 默认）；超时升级 report → Controller

---
