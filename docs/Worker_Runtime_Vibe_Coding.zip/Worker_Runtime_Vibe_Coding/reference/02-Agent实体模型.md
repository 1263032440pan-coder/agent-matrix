## 2. Agent 实体模型

### 2.1 两层结构：Definition（模板）与 Instance（实例）

```
AgentDefinition（agent_definition 表——静态配置，长期存在，跨项目复用）
  ├─ agent_id / name / role_description（→自动生成 system prompt）
  ├─ model_config（模型名——可与全局不同；空=用全局）
  ├─ plugins: JSON（插件白名单：["shell","file_rw","slide_generator",…]）
  ├─ skills: JSON（skill 白名单：skill_id 列表；AI 在白名单内自决）
  ├─ stage_affinity: JSON（环节亲和：["设计","架构"]——路由依据）
  ├─ scope: GLOBAL（全局模板）/ PROJECT（项目实例化）
  └─ source: BUILT_IN（内置）/ USER（用户自建）/ CONTROLLER_GENERATED（AI 动态生成）

AgentInstance（agent_instance 表——运行时状态机，项目内实体）
  ├─ definition_id → AgentDefinition
  ├─ project_id / status（§3 六态）
  ├─ context_ref（会话上下文——多轮累积；含已加载 skill/已产出摘要）
  ├─ fail_count / degraded_until（自愈计数）
  ├─ context_tokens / context_threshold（上下文使用/触发阈值——组装器
  │    每次组装写入，UI 压力条数据源；阈值随模型适配 §7.5+）
  └─ current_task_id（BUSY 时非空）
```

**分离的理由**：删 Definition 不影响在跑 Instance（模板只读）；同 Definition 可多实例并发（编码 Agent ×2 并行改两个模块）。

### 2.2 创建路径（三条）

| 路径 | 触发 | 行为 |
|---|---|---|
| **规划自动创建**（主路径） | /plan 完成后 AgentProvisioner 扫任务图 | 按环节亲和归组匹配模板 → 缺模板的环节用「默认 Agent 模板」兜底 → 批量实例化；无任务的环节不创建 |
| **用户显式创建** | UI「智能体管理」面板 | 填名称/角色描述/选模型/勾插件/勾 skill → Definition 入库（GLOBAL 或当前 PROJECT）→ 可被路由匹配 |
| **Controller 动态派生** | 监控发现能力缺口 | MANUAL 模式：请求用户批准创建；FULL_AUTO：按模板库自动匹配（默认关闭，配置项开启） |

### 2.3 默认 Agent 模板（内置五个，软件开发现阶段）

| 模板 | stage_affinity | 插件集 | 说明 |
|---|---|---|---|
| analyst | 项目理解,需求基线 | file_rw, web_search, webfetch, slide_generator | 前期调研+汇报 PPT |
| designer | 解决方案,原型设计,架构设计 | file_rw, web_search, webfetch, slide_generator, arch_diagram | 方案+图 |
| coder | 开发实现 | file_rw, shell, code_search, git, lsp | 编码三件套 |
| tester | 测试验证 | file_rw, shell, test_runner, code_search | 跑测+报告 |
| releaser | 交付打包,使用文档 | file_rw, shell, builder, slide_generator | 打包+交付文档 |

**术语澄清（2026-10-12 用户问询补充）**：
- **模板库** = `agent_definition` 表里全部 Definition 的集合（内置五个 seed + 用户自建 + Controller 动态生成的都在同一张表，scope 字段区分 GLOBAL/PROJECT）
- **默认模板** = 内置五个（analyst/designer/coder/tester/releaser）——安装即有、开箱即用的出厂配置；AgentProvisioner 优先从中匹配，用户可修改可停用可自建
- **AI 生成的模板** = Controller 动态派生（§2.2 路径 3：监控发现能力缺口时按模板库结构新建 Definition）——与用户自建的同等地位入表，UI 可辨识来源（source: BUILT_IN / USER / CONTROLLER_GENERATED）。**门（用户决策 2026-10-12）：AI 生成模板默认 scope=PROJECT（只服务当前项目），升级 GLOBAL 须用户在 UI 确认——AI 为单项目凑合的岗位配置未必值得全局复用，人把关；AI 生成永不标 BUILT_IN，不污染出厂配置**

**模板设计依据（用户问询补充，三层）**：
1. **skill 阶段结构归组**（直接来源）：九阶段（skill 包 software-project-delivery 定义）按职能归五组——输入侧（analyst：理解/需求，要汇报→PPT 插件）/ 设计侧（designer：方案/原型/架构，要画图→arch_diagram）/ 实现侧（coder）/ 验证侧（tester：test_runner 专属）/ 输出侧（releaser：打包/文档）；项目9 实测任务图即此形状
2. **opencode agents 实践对标**：其 build/plan/review 内置 agents 验证了"按职能切工具白名单"模式（plan/review 只读禁 edit/bash；我们按交付阶段进一步细分）
3. **task_type 实证**：stage_affinity 引用的九标准词 = 任务图 task_type 实际取值（P1 修订时核实库里真实在用）——环节亲和词不是发明，是任务图本来就产出的词

（模板数据 seed 进库，用户可改可自建——模板只是初始配置不是硬编码）

---
