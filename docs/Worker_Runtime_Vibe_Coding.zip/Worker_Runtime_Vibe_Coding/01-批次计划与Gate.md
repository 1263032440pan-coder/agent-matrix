# 批次计划与Gate

保持原文三个交付批次，批内细分12个执行任务。默认按表顺序实施，批次Gate通过后进入下一批；拆分不代表新增验收条款。

| 任务 | 文档 | 依赖 |
|---|---|---|
| B1-01 | [模型迁移与生命周期](tasks/B1-01-模型迁移与生命周期.md) | 无；先完成仓库现状核查 |
| B1-02 | [路由Provisioner与独立执行](tasks/B1-02-路由Provisioner与独立执行.md) | B1-01 |
| B1-03 | [底座插件与基础PPT](tasks/B1-03-底座插件与基础PPT.md) | B1-01；与 B1-02 注册面联调 |
| B1-04 | [SessionStore与核心压缩](tasks/B1-04-SessionStore与核心压缩.md) | B1-01、B1-03；接入 B1-02 派发边界 |
| B1-05 | [管理UI与批次1集成验收](tasks/B1-05-管理UI与批次1集成验收.md) | B1-01 至 B1-04 |
| B2-01 | [ACP消息与等待关系](tasks/B2-01-ACP消息与等待关系.md) | 批次1 PASS |
| B2-02 | [Controller与规划链路升级](tasks/B2-02-Controller与规划链路升级.md) | B2-01 |
| B2-03 | [交付清单对账与五闸](tasks/B2-03-交付清单对账与五闸.md) | B2-02 |
| B2-04 | [ACP回放与Controller可观测性](tasks/B2-04-ACP回放与Controller可观测性.md) | B2-01 至 B2-03 |
| B3-01 | [配额失败传播Checkpoint与压缩增强](tasks/B3-01-配额失败传播Checkpoint与压缩增强.md) | 批次2 PASS |
| B3-02 | [MCP及软件工程工具生态](tasks/B3-02-MCP及软件工程工具生态.md) | B3-01 |
| B3-03 | [LLMProvider化与最终回归](tasks/B3-03-LLMProvider化与最终回归.md) | B3-01、B3-02 |

## 批次边界

- 批次1：B1-01至B1-05，骨架、底座插件、核心压缩和完整批次1UI。核心压缩不得后置。
- 批次2：B2-01至B2-04，ACP、Controller、规划迁移、对账五闸及对应UI。
- 批次3：B3-01至B3-03，配额/快照/增强压缩、MCP生态、LLM Provider化和最终回归。

## 每批Gate

1. 范围内条款完成映射，阻塞为0，无后续批次伪实现冒充完成。
2. 相关pytest离线mock、插件单测、接口与UI冒烟通过；记录命令和退出码。
3. 真实链路实测并保留产物/事件证据；缺模型接口等条件则标BLOCKED，不把mock写成实测。
4. 旧单Worker与已有规划/工具循环回归通过；缺陷修复后复验。
5. 交付代码/依赖/迁移/测试/RTM/交接记录，评审得出PASS/FAIL/BLOCKED。

完整边界见 [原文批次](reference/10-交付批次.md) 与 [测试计划](reference/14-测试计划.md)。
